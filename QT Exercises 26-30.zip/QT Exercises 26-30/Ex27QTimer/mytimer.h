#ifndef MYTIMER_H
#define MYTIMER_H

#include <QtCore>
//inheritance to use it
class MyTimer : public QObject
{
    //convert this class into object
    Q_OBJECT
public:
    MyTimer();
    QTimer *timer;

public slots:
    void MySlot();
};

#endif // MYTIMER_H
