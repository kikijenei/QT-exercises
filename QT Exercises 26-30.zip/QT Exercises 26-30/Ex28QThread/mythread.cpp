#include "mythread.h"
#include <QtCore>
#include <QDebug>

//Ex29 Priority
//Ex30 QMutex

MyThread::MyThread()
{

}

void MyThread::run()
{
    //qDebug() << "Running...";
    qDebug() << this->name << "Running...";

    for(int i = 0; i < 100; i++){
        QMutex mutex;
        mutex.lock();
        if(this->Stop){
            break;
        }
        mutex.unlock();
        this->sleep(10);

        qDebug() << this->name << i;
    }
}
