#include <QApplication>
#include <QWidget>
#include <QGridLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include <QtGui>
#include <QtCore>

int main(int argc, char *argv[]){
    QApplication app(argc, argv);
    //Ex.7
    /*
    QLabel *label = new QLabel("<h2>Hello <font color=red><i>world</i></font></h2>");
    //apare bold si italic: ("<b>Hello</b> <i>world</i>")
    label->show();
    */

    QWidget *window = new QWidget;
    window->setWindowTitle("My App");

    //Ex.8
    /*
    QPushButton *button1 = new QPushButton("one");
    QPushButton *button2 = new QPushButton("two");
    QPushButton *button3 = new QPushButton("three");

    //QHBoxLayout *hlayout = new QHBoxLayout;
    QVBoxLayout *vlayout = new QVBoxLayout;

    hlayout->addWidget(button1);
    hlayout->addWidget(button2);
    hlayout->addWidget(button3);
    vlayout->addWidget(button1);
    vlayout->addWidget(button2);
    vlayout->addWidget(button3);

    window->setLayout(vlayout);
    */

    //Ex.9
    QGridLayout *layout = new QGridLayout;

    QLabel *label1 = new QLabel("Name: ");
    QLineEdit *txtName = new QLineEdit;

    QLabel *label2 = new QLabel("Name: ");
    QLineEdit *txtName2 = new QLineEdit;

    layout->addWidget(label1, 0, 0);
    layout->addWidget(txtName, 0, 1);

    layout->addWidget(label2, 1, 0);
    layout->addWidget(txtName2, 1, 1);

    QPushButton *button = new QPushButton("Ok");
    layout->addWidget(button, 2, 0, 1, 2);

    window->setLayout(layout);

    window->show();

    return app.exec();

}
