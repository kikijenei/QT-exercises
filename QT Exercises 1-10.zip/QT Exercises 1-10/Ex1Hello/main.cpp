#include <QtCore/QCoreApplication>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QString mStr = "Helloo World";

    qDebug() << mStr;

    qDebug() << "Hello World";

    return a.exec();
}
