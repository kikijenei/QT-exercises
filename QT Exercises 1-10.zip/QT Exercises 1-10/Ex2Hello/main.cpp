#include "mainwindow.h"

#include <QApplication>
#include <QLabel>
#include <QtGui>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    //QLabel l ( "Hello World!" );
    //l.show();
    return a.exec();
}
