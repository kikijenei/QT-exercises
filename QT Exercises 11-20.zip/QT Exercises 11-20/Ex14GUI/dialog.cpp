#include "dialog.h"
#include "./ui_dialog.h"
#include <QMessageBox>

#include <QtGui>
#include <QtCore>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    //ui->label->setText("<b>Hello</b> everyone");
    ui->checkBox->setChecked(true);

   //ui->comboBox->addItem("Hi");
    for(int i = 0; i < 9; i++){
        ui->comboBox->addItem(QString::number(i) + " item");
    }

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    //QMessageBox::information(this, "Title here", "Hellooo");
    //ui->lineEdit->setText("Hello!");
    QMessageBox::information(this, "Title", ui->lineEdit->text());
}


void Dialog::on_pushButton_2_clicked()
{
    if(ui->checkBox->isChecked()){
        QMessageBox::information(this, "Cats", "You like cats.");
    }
    else
    {
        QMessageBox::information(this, "Cats", "You do not like cats....");
    }
}


void Dialog::on_pushButton_3_clicked()
{
    if(ui->radioButton1->isChecked())
    {
        QMessageBox::information(this, "Title", ui->radioButton1->text());
    }
    if(ui->radioButton2->isChecked())
    {
        QMessageBox::information(this, "Title", ui->radioButton2->text());
    }

}


void Dialog::on_pushButton_4_clicked()
{
    QMessageBox::information(this, "Title", ui->comboBox->currentText());
    //QMessageBox::information(this, "Title", ui->comboBox->currentIndex());

}

