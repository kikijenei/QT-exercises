#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QString>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    QDir mDir("D:/Proiecte QT");

    //QDir mDir("D:/Proiecte QT");
    //QDir mDir;
    //QString mPath = "D:/Proiecte QT/abc";
    //qDebug() << mDir.exists();
    /*
    foreach(QFileInfo mItem, mDir.drives()){
        qDebug() << mItem.absoluteFilePath();
    }
    */

    /*
    if(!mDir.exists()){
      mDir.mkpath(mPath);
        qDebug() << "Created";
    }
    else{
        qDebug()<< "Already exists";
    }

    */

    foreach(QFileInfo mitem, mDir.entryInfoList()){
        //qDebug() << mitem.absoluteFilePath();
        if(mitem.isDir()) qDebug() << "Dir: " << mitem.absoluteFilePath();
        if(mitem.isFile()) qDebug() << "File: " << mitem.absoluteFilePath();
    }
    return a.exec();
}
