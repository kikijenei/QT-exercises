#include "StivaStatica.h"
#include<iostream>

using namespace std;
Array_Stack::Array_Stack(int max) { //definire constructor 
	this -> max = max;
	this -> top = 0;
	this -> vector = new int[max];

}
Array_Stack::Array_Stack(const Array_Stack& param) {//constructor de copiere
	this->max = param.max;
	this->top = param.top;
	this->vector = new int[max];
	for (int i = 0; i < top; ++i) {
		this->vector[i] = param.vector[i];
	}
}
Array_Stack::~Array_Stack() { //destructor
	delete[] this->vector;
	this->vector = nullptr;
	//delete[] this->vector;
	this->top = 0;
	this->max = 0;
}
bool Array_Stack::isempty() {
	return this->top == 0;
}

bool Array_Stack::isfull() {
	return this->top == this->max;
}
int Array_Stack::peek() {
	if (isempty()) {
		throw Stack_Underflow();
	}
	else return this->vector[this->top];
}
int Array_Stack::pop() {//scoatere
	if (isempty()) {
		throw Stack_Overflow();
	}
	else return this->vector[--this->top];

}
void Array_Stack::push(int element) {
	if (isfull()) {
		throw Stack_Overflow();
	}
	this->vector[this->top++] = element;

}
void Array_Stack::print(){
	for (int i = 0; i < top; ++i) {
		cout << vector[i] << " ";
	}
	cout << endl;
}
