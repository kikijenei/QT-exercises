#include <QCoreApplication>
#include <QDebug>
#include <QVector>


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QVector<QString> Vect(5);

    QList<int> List;
    QList<int> List2;

    List << 2 << 3 << 1 << 0;
    List2 << 1 << 5 << 15 << 20;

    //QList<int>::const_iterator Iter = qFind(List2.begin(), List2.end(), 15);;

    //qSort(List.begin() + 1, List.end() - 1);

    foreach(int i, List){
        qDebug() << i;
    }

    return a.exec();
}
