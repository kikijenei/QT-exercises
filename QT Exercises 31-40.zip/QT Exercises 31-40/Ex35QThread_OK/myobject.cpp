#include "myobject.h"
#include <QObject>
#include <QDebug>

MyObject::MyObject(QObject *parent)
    : QObject{parent}
{}

void MyObject::DoSetup(QThread &cThread){
    connect(&cThread, SIGNAL(started()), this, SLOT(SoWork()));
}

void MyObject::DoWork(){
    for(int i = 0; i < 100; i++){
        qDebug() << i;
        //msleep(200);
    }
}
