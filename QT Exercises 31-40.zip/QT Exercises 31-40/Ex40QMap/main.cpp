//Map - items are always sorted by keys
//Hash - items are arbitrarily ordered (hash in the backround - alpha numerical representation)
#include <QCoreApplication>
//#include <QMap>
//Ex41 QHash
#include <QHash>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //QMap<int, QString> Employees;
    QHash<int, QString> Employees;

    Employees.insert(1, "Bob");
    Employees.insert(2, "Chad");
    Employees.insert(3, "Mary");

    qDebug() << "3 = " << Employees.value(3);

    // foreach(int i, Employees.keys())
    // {
    //     qDebug() << Employees[i];
    // }

    // QHashIterator<int, QString> Iter(Employees);
    // while(Iter.hasNext())
    // {
    //     Iter.next();
    //     qDebug() << Iter.key() << " = " << Iter.value();
    // }

    return a.exec();
}
